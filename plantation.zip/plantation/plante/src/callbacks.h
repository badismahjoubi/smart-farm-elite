#include <gtk/gtk.h>

typedef struct plante plante;
struct plante{
char nom[30];
char typeVegetal[30];
char dateAgriculture[30];
char dateRecolte[30];
int nbVegetal;
int prix;
};
int i,j;

GtkWidget *acceuil;
  GtkWidget *gestion_Plante;
  GtkWidget *gestio_Graine;
  GtkWidget *catalogue;




void
on_AcceuilgestionPlante_clicked         (GtkButton       *button,
                                        gpointer         user_data);


void
on_treeview1_row_activated             (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data);

void
on_gestionPlante_Acceuil_clicked        (GtkButton       *button,
                                        gpointer         user_data);

void
on_AjouterPlante_clicked                (GtkButton       *button,
                                        gpointer         user_data);

void
on_ModifierPlante_clicked               (GtkButton       *button,
                                        gpointer         user_data);

void
on_SupprimerPlante_clicked              (GtkButton       *button,
                                        gpointer         user_data);



void
on_chercherPlante_clicked               (GtkButton       *button,
                                        gpointer         user_data);



/*void
on_SupprimerPlante_clicked             (GtkButton       *button,
                                        gpointer         user_data);

void
on_AjouterPlante_clicked               (GtkButton       *button,
                                        gpointer         user_data);

void
on_gestionPlante_Acceuil_clicked       (GtkButton       *button,
                                        gpointer         user_data);

void
on_ModifierPlante_clicked              (GtkButton       *button,
                                        gpointer         user_data);

void
on_chercherPlante_clicked              (GtkButton       *button,
                                        gpointer         user_data);

void
on_AjouterGraine_clicked               (GtkButton       *button,
                                        gpointer         user_data);

void
on_gestionGraine_Acceuil_clicked       (GtkButton       *button,
                                        gpointer         user_data);

void
on_SupprimerGraine_clicked             (GtkButton       *button,
                                        gpointer         user_data);

void
on_ModifierGraine_clicked              (GtkButton       *button,
                                        gpointer         user_data);

void
on_chercherGraineclicked               (GtkButton       *button,
                                        gpointer         user_data);*/

/*void
on_lannee_la_plus_seche_clicked        (GtkButton       *button,
                                        gpointer         user_data);*/
