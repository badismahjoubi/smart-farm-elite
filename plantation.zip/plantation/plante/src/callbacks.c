#ifdef HAVE_CONFIG_H
#  include <config.h>
#endif

#include <gtk/gtk.h>

#include "callbacks.h"
#include "interface.h"
#include "support.h"
#include"tree.h"
#include"crud.h"


void
on_AcceuilgestionPlante_clicked         (GtkButton       *button,
                                        gpointer         user_data)

{
/*preparation du treeView*/
GtkWidget *p;
GtkWidget *p1;
FILE*f1=NULL;
plante h;
gtk_widget_hide (acceuil);
gestion_Plante = create_gestion_Plante ();
p=lookup_widget(gestion_Plante,"treeview1");
p1=lookup_widget(gestion_Plante,"treeview3");
i=0;
Plantetree(p,"plantes.txt");

i=0;
Plantetree(p1,"plantes.txt");

gtk_widget_show (gestion_Plante);

}



void
on_treeview1_row_activated             (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data)
{


 	gchar *nom;
        gchar *typeVegetal;
        gchar *dateAgriculture;
        gchar *dateRecolte;
        gint prix;
        gint nbVegetal;

        int x;
        GtkTreeModel     *model;
        GtkTreeIter iter;
        GtkWidget *p=lookup_widget(gestion_Plante,"treeview1");
        GtkTreeSelection *selection = gtk_tree_view_get_selection(GTK_TREE_VIEW(p));
        if (gtk_tree_selection_get_selected(selection, &model, &iter))
        {
                gtk_tree_model_get (model,&iter,0,&nom,1,&typeVegetal,2,&dateAgriculture,3,&dateRecolte,4,&nbVegetal,5,&prix,-1);//recuperer les information de la ligne selectionneé

                gtk_entry_set_text(GTK_ENTRY(lookup_widget(gestion_Plante,"entry2")),dateAgriculture);
                gtk_entry_set_text(GTK_ENTRY(lookup_widget(gestion_Plante,"entry3")),dateRecolte);

                gtk_spin_button_set_value (GTK_SPIN_BUTTON(lookup_widget(gestion_Plante,"spinbutton4")),prix);
                gtk_spin_button_set_value (GTK_SPIN_BUTTON(lookup_widget(gestion_Plante,"spinbutton3")),nbVegetal);

                if(strcmp(typeVegetal,"Annuelle")==0) x=0;
                if(strcmp(typeVegetal,"bisannuelle")==0) x=1;




                gtk_combo_box_set_active(GTK_COMBO_BOX(lookup_widget(gestion_Plante,"combobox2")),x);
		GtkWidget* msg=lookup_widget(gestion_Plante,"label25");
                gtk_label_set_text(GTK_LABEL(msg),nom);
		


                gtk_widget_show(lookup_widget(gestion_Plante,"button7"));//afficher le bouton modifier
        GtkWidget* msg1=lookup_widget(gestion_Plante,"label27");
        gtk_widget_hide(msg1);

}



}


void
on_gestionPlante_Acceuil_clicked        (GtkButton       *button,
                                        gpointer         user_data)

{
gtk_widget_show (acceuil);
        gtk_widget_destroy (gestion_Plante);

}

void
on_AjouterPlante_clicked                (GtkButton       *button,
                                      gpointer         user_data)
{

GtkWidget *cal1;
GtkWidget *cal2;
GtkWidget *combobox;
GtkWidget *labelNom;
GtkWidget *labelsuccess;
GtkWidget *labelCombo;
GtkWidget *labelExist;
FILE*f=NULL;
plante h;
int jj1,mm1,aa1,jj2,mm2,aa2,b=1;

labelNom=lookup_widget(gestion_Plante,"label9");
labelCombo=lookup_widget(gestion_Plante,"label15");
labelExist=lookup_widget(gestion_Plante,"label8");
labelsuccess=lookup_widget(gestion_Plante,"label10");
combobox=lookup_widget(gestion_Plante,"combobox1");
cal1=lookup_widget(gestion_Plante,"calendar1");
cal2=lookup_widget(gestion_Plante,"calendar2");
           gtk_widget_hide (labelsuccess);

strcpy(h.nom,gtk_entry_get_text(GTK_ENTRY(lookup_widget(gestion_Plante,"entry1"))));
// saisie controlé
if(strcmp(h.nom,"")==0){
                gtk_widget_show (labelNom);
b=0;

}else
{
           gtk_widget_hide (labelNom);
}

if(gtk_combo_box_get_active (GTK_COMBO_BOX(combobox))==-1){
                gtk_widget_show (labelCombo);
b=0;
}
else{

           gtk_widget_hide (labelCombo);
}
if(b==1){

h.nbVegetal =gtk_spin_button_get_value_as_int (GTK_SPIN_BUTTON (lookup_widget(gestion_Plante,"spinbutton1")));
h.prix =gtk_spin_button_get_value_as_int (GTK_SPIN_BUTTON (lookup_widget(gestion_Plante,"spinbutton2")));
strcpy(h.typeVegetal,gtk_combo_box_get_active_text(GTK_COMBO_BOX(combobox)));
//recuperer la date du calendrier jour,mois,annee
gtk_calendar_get_date (GTK_CALENDAR(cal1),
                       &aa1,
                       &mm1,
                       &jj1);
gtk_calendar_get_date (GTK_CALENDAR(cal2),
                       &aa2,
                       &mm2,
                       &jj2);
if(exist(h.nom)==1) {

                gtk_widget_show (labelExist);

}
else{
           gtk_widget_hide (labelExist);
f=fopen("plantes.txt","a+");
fprintf(f,"%s %s %d/%d/%d %d/%d/%d %d %d\n",h.nom,h.typeVegetal,jj1,mm1+1,aa1,jj2,mm2+1,aa2,h.nbVegetal,h.prix);
fclose(f);
                gtk_widget_show (labelsuccess);


/*mise a jour du treeView*/
GtkWidget *p;
p=lookup_widget(gestion_Plante,"treeview1");
Plantetree(p,"plantes.txt");



}
}

}

void
on_ModifierPlante_clicked               (GtkButton       *button,
                                        gpointer         user_data)
{
plante h;
        strcpy(h.nom,gtk_label_get_text(GTK_LABEL(lookup_widget(gestion_Plante,"label25"))));
        strcpy(h.typeVegetal,gtk_combo_box_get_active_text(GTK_COMBO_BOX(lookup_widget(gestion_Plante,"combobox2"))));
        strcpy(h.dateAgriculture,gtk_entry_get_text(GTK_ENTRY(lookup_widget(gestion_Plante,"entry2"))));
        strcpy(h.dateRecolte,gtk_entry_get_text(GTK_ENTRY(lookup_widget(gestion_Plante,"entry3"))));
        h.nbVegetal =gtk_spin_button_get_value_as_int (GTK_SPIN_BUTTON (lookup_widget(gestion_Plante,"spinbutton3")));
        h.prix =gtk_spin_button_get_value_as_int (GTK_SPIN_BUTTON (lookup_widget(gestion_Plante,"spinbutton4")));

        supp(h.nom);
        ajout(h);
        Plantetree(lookup_widget(gestion_Plante,"treeview1"),"plantes.txt");
        GtkWidget* msg=lookup_widget(gestion_Plante,"label26");
        gtk_widget_show(msg);


}
void
on_SupprimerPlante_clicked              (GtkButton       *button,
                                        gpointer         user_data)
{

 GtkTreeSelection *selection;
        GtkTreeModel     *model;
        GtkTreeIter iter;
        GtkWidget* p;
        GtkWidget *label;
        gchar* nom;
        label=lookup_widget(gestion_Plante,"label27");
        p=lookup_widget(gestion_Plante,"treeview1");
        selection = gtk_tree_view_get_selection(GTK_TREE_VIEW(p));
        if (gtk_tree_selection_get_selected(selection, &model, &iter))
        {  gtk_tree_model_get (model,&iter,0,&nom,-1);
           gtk_list_store_remove(GTK_LIST_STORE(model),&iter);//supprimer la ligne du treeView

           supp(nom);// supprimer la ligne du fichier

           gtk_widget_hide (label);}else{
                gtk_widget_show (label);
        }


}




void
on_chercherPlante_clicked               (GtkButton       *button,
                                        gpointer         user_data)
{

GtkWidget *p1;
GtkWidget *entry;
GtkWidget *labelType;
GtkWidget *nbResultat;
GtkWidget *message;
char type[30];
char chnb[30];
int b=0,nb;
entry=lookup_widget(gestion_Plante,"entry7");
labelType=lookup_widget(gestion_Plante,"label64");
p1=lookup_widget(gestion_Plante,"treeview3");

strcpy(type,gtk_entry_get_text(GTK_ENTRY(entry)));
if(strcmp(type,"")==0){
  gtk_widget_show (labelType);b=0;
}else{
b=1;
gtk_widget_hide (labelType);}

if(b==0){return;}else{

nb=ChercherPlanteTree(p1,"plantes.txt",type);//type entry ecrie par lutilisateur
/* afficher le nombre de resultats obtenue par la recherche */
sprintf(chnb,"%d",nb);
nbResultat=lookup_widget(gestion_Plante,"label66");
message=lookup_widget(gestion_Plante,"label65");
gtk_label_set_text(GTK_LABEL(nbResultat),chnb);//set_text n'accepte que chaine de caractere 

gtk_widget_show (nbResultat);
gtk_widget_show (message);




}

}











void
on_lannee_la_plus_seche_clicked        (GtkButton       *button,
                                        gpointer         user_data)
{

}

