#include<string.h>
#include<stdio.h>
#include<stdlib.h>
#include "callbacks.h"
#include<string.h>

/***************************************************** plantes *******************************/
void ajout( plante h){
FILE*f=NULL;
f=fopen("plantes.txt","a+");
fprintf(f,"%s %s %s %s %d %d\n",h.nom,h.typeVegetal,h.dateAgriculture,h.dateRecolte,h.nbVegetal,h.prix);
fclose(f);

}

int exist(char*nom){
FILE*f=NULL;
 plante h;
f=fopen("plantes.txt","r");
while(fscanf(f,"%s %s %s %s %d %d\n",h.nom,h.typeVegetal,h.dateAgriculture,h.dateRecolte,&h.nbVegetal,&h.prix)!=EOF){
if(strcmp(h.nom,nom)==0)return 1;
}
fclose(f);
return 0;
}


void supp(char*nom){
FILE*f=NULL;
FILE*f1=NULL;
 plante h;
f=fopen("plantes.txt","r");

f1=fopen("ancien.txt","w+");
while(fscanf(f,"%s %s %s %s %d %d\n",h.nom,h.typeVegetal,h.dateAgriculture,h.dateRecolte,&h.nbVegetal,&h.prix)!=EOF){
if(strcmp(nom,h.nom)!=0)fprintf(f1,"%s %s %s %s %d %d\n",h.nom,h.typeVegetal,h.dateAgriculture,h.dateRecolte,h.nbVegetal,h.prix);
}
fclose(f);
fclose(f1);
remove("agents.txt");
rename("ancien.txt","plantes.txt");
}

