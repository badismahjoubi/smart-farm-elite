
void ajout( plante h);
int exist(char*nom);
void supp(char*nom);



/************************/
