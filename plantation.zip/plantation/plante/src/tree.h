void Plantetree(GtkWidget* treeview1,char*l);
int ChercherPlanteTree(GtkWidget* treeview1,char*l,char*type);

